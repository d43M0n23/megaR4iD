


1. Installing debian Package
	sudo dpkg -i storcli_1.0_all.deb

2. verifying , if the package is installed successfully or not.
   dpkg -l | grep -i storcli

3. Run the commands    with super user as below.
	sudo /opt/MegaRAID/storcli/storcli adpcount

