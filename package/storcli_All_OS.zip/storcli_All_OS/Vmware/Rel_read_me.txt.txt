1)unzip the storcli

2)change the permission of the bianry
	chmod +x storcli  