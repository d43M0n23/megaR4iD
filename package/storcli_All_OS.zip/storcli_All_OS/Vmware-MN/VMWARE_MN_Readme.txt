

1. The installed VIB Package can be list using command 
	"esxcli software vib list "
 
2. The VIB Package can be installed using the command
	"esxcli software vib install -v=vmware-esx-storcli.vib"

3.The VIB Package can be removed using the command
	"esxcli software vib remove -n=vmware-esx-storcli.vib"

Note: this binary is for all 5.x versions less than 5.5.