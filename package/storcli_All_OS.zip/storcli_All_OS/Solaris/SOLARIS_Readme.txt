Requirement for Storcli Execution 

1) Download "libgcc-3.4.6-....-local.gz" from http://www.sunfreeware.com or http://ftp.riken.jp/Sun/sunfreeware/i386/5.10/
	
2) Copy it to the setup and Extract.

3) Install the Package using bellow command.

	pkgadd -d libgcc-3.4.6-....-local.pkg

4) Prior to executing standalone Storcli binary, check the permissions of Storcli binary. 

	"ls -l storcli"

5) If executable permissions are not given, run the below command to change the permissions.

	"chmod +x storcli"

