THIS IS A OPEN POWER PC LITTLE ENDIAN DISTRIBUTION FOR 64 BIT MACHINES 

To install StorCLI, perform the following steps:
1. Unzip the StorCLI package.
2. To install the StorCLI , extract the binary from the respective *.tarfile.
